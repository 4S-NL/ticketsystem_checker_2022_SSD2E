@extends('layouts.base')

@section('content')
    <h2>Bedankt voor uw bestelling!!</h2>
    <h3> Hier zijn uw bestelgegevens: </h3>

    {{-- Order data | Event data behorend bij order | tickets nodig behorend bij de order --}}
@endsection
